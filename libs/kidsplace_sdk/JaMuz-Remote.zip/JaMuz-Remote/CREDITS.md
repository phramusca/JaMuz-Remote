# Credits

## Libraries

* TODO

* [Weblate](https://hosted.weblate.org/engage/jamuz/): Online translation tool

## Contributions

* [Thanks to all contributors](https://github.com/phramusca/JaMuz-Remote/graphs/contributors)
* You too can [contribute](CONTRIBUTING.md), even if you are not a developer.
