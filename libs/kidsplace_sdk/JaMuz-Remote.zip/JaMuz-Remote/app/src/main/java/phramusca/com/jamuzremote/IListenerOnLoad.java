package phramusca.com.jamuzremote;

public interface IListenerOnLoad {
    void onLoadMore();

    void onLoadTop();
}