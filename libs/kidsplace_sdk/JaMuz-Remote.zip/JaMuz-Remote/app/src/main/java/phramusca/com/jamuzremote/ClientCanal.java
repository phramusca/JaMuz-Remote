package phramusca.com.jamuzremote;

public class ClientCanal {
    public static final int REMOTE = 1;
    public static final int SYNC = 2;
    //Then canals, starting 100 are for download process
}

