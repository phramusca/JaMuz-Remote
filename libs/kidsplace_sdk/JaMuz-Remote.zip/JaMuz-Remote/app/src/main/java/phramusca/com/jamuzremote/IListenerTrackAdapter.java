package phramusca.com.jamuzremote;

public interface IListenerTrackAdapter {
    void onClick(Track item, int position);
}
