package phramusca.com.jamuzremote;

public interface IListenerSyncDown {
    void setStatus(Track track, String msg, int position);
}