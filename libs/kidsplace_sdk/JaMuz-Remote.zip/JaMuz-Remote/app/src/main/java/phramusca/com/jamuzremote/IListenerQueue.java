package phramusca.com.jamuzremote;

public interface IListenerQueue {
    void onPositionChanged(int positionPlaying);
}
