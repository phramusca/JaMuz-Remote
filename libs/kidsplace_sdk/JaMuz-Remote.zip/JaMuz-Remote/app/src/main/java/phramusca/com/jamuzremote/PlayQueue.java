package phramusca.com.jamuzremote;

import java.util.ArrayList;

class PlayQueue {
    static TrackQueue queue = new TrackQueue(new ArrayList<>(), -1);
}
