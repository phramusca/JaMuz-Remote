package phramusca.com.jamuzremote;

public interface IListenerAdapterAlbum {
    void onClick(AdapterListItemAlbum adapterListItemAlbum);
}
