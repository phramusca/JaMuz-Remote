package com.beaglebuddy;

public class MP3 {
}